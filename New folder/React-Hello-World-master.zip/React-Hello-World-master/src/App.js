import React from 'react'
import Restaurant from './component/basics/Restaurant';
import UseState from "./component/Hooks/useState";
import UseEffect from './component/Hooks/useEffect';

const App = () => {
  return ( 
    <>
      <UseEffect/>
    </>
  );
};

export default App ;
   